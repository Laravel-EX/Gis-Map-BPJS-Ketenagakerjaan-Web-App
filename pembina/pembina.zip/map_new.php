<?php error_reporting(0); ?>				<div class="col-md-12">
			        <div class="col-lg-3">
			          <!-- small box -->
			          <div class="small-box" style="background-color: #ECECEC; box-shadow: 0px 0px 5px;">
			            <div class="inner" style="color: #1E824C;">
			              <h3>PESERTA</h3>
			            </div>
			            <div class="icon">
			              <i class="ion fa fa-book"></i>
			            </div>
			            <a href="?page=show.php" class="small-box-footer" style="color: black;">More info <i class="fa fa-arrow-circle-right"></i></a>
			          </div>
			        </div><!-- ./col -->
			        <div class="col-lg-3">
			          <!-- small box -->
			          <div class="small-box" style="background-color: #ECECEC; box-shadow: 0px 0px 5px;">
			            <div class="inner" style="color: #1E824C;">
			              <h3>MAP</h3>
			            </div>
			            <div class="icon">
			              <i class="ion fa fa-book"></i>
			            </div>
			            <a href="?page=tampil.php" class="small-box-footer" style="color: black;">More info <i class="fa fa-arrow-circle-right"></i></a>
			          </div>
			        </div><!-- ./col -->
			        <div class="col-lg-3">
			          <!-- small box -->
			          <div class="small-box" style="background-color: #ECECEC; box-shadow: 0px 0px 5px;">
			            <div class="inner" style="color: #1E824C;">
			              <h3>PEMBINA</h3>
			            </div>
			            <div class="icon">
			              <i class="ion fa fa-book"></i>
			            </div>
			            <a href="?page=pembina/pembina.php" class="small-box-footer" style="color: black;">More info <i class="fa fa-arrow-circle-right"></i></a>
			          </div>
			        </div><!-- ./col -->
			        <div class="col-lg-3">
			          <!-- small box -->
			          <div class="small-box" style="background-color: #ECECEC; box-shadow: 0px 0px 5px;">
			            <div class="inner" style="color: #1E824C;">
			              <h3>LOGOUT</h3>
			            </div>
			            <div class="icon">
			              <i class="ion fa fa-book"></i>
			            </div>
			            <a href="?page=logout.php" class="small-box-footer" style="color: black;">More info <i class="fa fa-arrow-circle-right"></i></a>
			          </div>
			        </div><!-- ./col -->
			        
    				
				</div>

			