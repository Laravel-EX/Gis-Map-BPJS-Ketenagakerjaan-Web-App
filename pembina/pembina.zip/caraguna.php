<style type="text/css">
  p{color: red;
    font-size: 20px;}
</style>
        <div class="col-md-12">
         
          <h1>Cara Penggunaan</h1>
          <h3>1. Set Posisi MAP Kantor Cabang</h3>
          <p>
            Setelah login sebagai Admin Kantor Cabang, Kita set terlebih dahulu posisi map di menu Kantor. 
            <img src="cara/kantor.png" width="100%">
          </p>
          <p>
          Lalu Klik Tombol SET dan klik 2x posisi Kantor Cabang di map yang tersedia, Maka kordinat Latitude dan Longitude akan muncul lalu klik tombol Simpan.
          <img src="cara/kantormap.png" width="100%"></p>
          <br>
          <h3>2. Set Username dan Password Pembina</h3>
          <p>Klik Menu Pembina, Lalu Pilih Pembina yang akan dibuat username dan passwordnya dengan mengklik tombol SET. Apabila Username dan password sudah ada maka tombol akan berubah  menjadi EDIT</p>
          <img src="cara/pembina.png" width="100%">
          <p>
          Isi Username dan Password lalu klik tombol Simpan. 
          <img src="cara/pembina1.png" width="100%"></p>
             <br><br>
             <h3>3. Set Posisi MAP peserta yang sudah terdaftar</h3>
             <p>Untuk melakukan set posisi map, klik menu PESERTA lalu klik tombol SET yang ada di list. Apabila map sudah di set, maka tombol SET akan berubah menjadi EDIT.
             <img src="cara/peserta.png" width="100%">
             </p>
            <p>Jika posisi map tidak sesuai, tahan tombol Ctrl pada keyboard dan scroll mouse untuk memperbesar atau memperkecil gambar map. Klik 2x pada map jika sudah dapat posisi lokasinya, maka kordinat X dan Y akan muncul serta Alamat akan muncul di Form. Lakukan perubahan pada form lain jika ada yang ingin dirubah.
            <img src="cara/peserta1.png" width="100%">
            Apabila ada penambahan peserta baru, klik menu PESERTA lalu klik tombol Tambah. Maka tampilan akan sama dengan gambar diatas, namun data kita isi semua form yang ada di dalamnya. Bedanya di tambah peserta kita pilih siapa pembina dari perusahaan tersebut.
            <img src="cara/tambahpeserta.png" width="100%">
            </p><br><br>
             <h3>4. Menambah User Admin Baru</h3>
            <p>Klik Menu USER lalu klik tombol Tambah.
            <img src="cara/tambah.png" width="100%"></p><br><br>
            <h3>5. Melihat Marker Map Peserta</h3>
            <p>klik menu MAP maka akan muncul tampilan seperti ini<br>
            <img src="cara/tampilmap.png" width="50%"><br>Ketika klik salah satu marker, maka akan muncul detail Nama, Alamat, dan Foto Peserta.</p>
        </div>